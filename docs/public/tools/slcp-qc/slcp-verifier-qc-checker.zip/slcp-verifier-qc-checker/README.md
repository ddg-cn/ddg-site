# SLCP Verifier Tool – Quality Checker

Checks a filled offline **SLCP Verifier Tool (1.7.x)** and writes an Excel report. The tool file itself is never modified.

There are two ways to use it:
- **Online:** https://scdd.pro/en/slcp-qc.html (中文: https://scdd.pro/zh/tools/slcp-qc.html) runs this checker inside your browser. The file is not uploaded anywhere.
- **On your PC:** use this package (below).

## How to run
Requires Python 3.9+ with `openpyxl` (`py -m pip install openpyxl`).
- **Drag and drop:** drop one or more `.xlsm` files onto `Run Quality Checker.bat`.
- **Command line:** `py slcp_qc_checker.py "<tool>.xlsm" [-o "<report>.xlsx"]`

The report is saved next to the tool as `<tool name> - QC Report <yymmdd>.xlsx`. It has three sheets:
- **Summary:** counts per rule, plus checks that could not run on this tool.
- **Issues:** one row per finding with severity, rule, question number and key. The *Tool Row* link opens the tool at that row (keep the report in the same folder as the tool).
- **Rules:** the full rule catalogue.

Severity: **Error** = must fix · **Warning** = review · **Info** = note.

## What it reads
- Inputs come from the `SLCP Data Collection Tool` sheet: S Facility Response, Y Verification Selection, AB Corrected Response, AH Verification Data, AN Non-Compliance, AP Legal Reference.
- Question metadata (data type, option list, show/hide logic, verification type, multi-select groups) comes from `Main Survey Actual`, so question numbers in the report are the ones your tool shows.
- The **effective answer** is the Corrected Response if one is given, otherwise the Facility Response. An *Inaccurate* checklist option with a blank correction counts as un-ticked. All logic and relevance checks use the effective answer, and questions that are hidden by show/hide logic are not checked.

## Rule groups
| Group | IDs | Summary |
|---|---|---|
| Language | LANG-01..04 | Verification Data, Corrected Response and verifier answers in English (except "in local language as per business license" questions). A facility answer in another language cannot be *Accurate*. |
| Selection | SEL-01..16 | Accurate → no correction. Inaccurate/Updated → a correction that differs from the facility answer, plus Verification Data. Not visible → blank facility answer. No longer applicable → no correction or data. A facility answer needs a selection, and the selection must be in the question's list. Also: mandatory narrative, placeholder text. Unticked checklist options are valid answers. |
| Data type | DATA-01..08 | Whole numbers, non-negative numbers, 0–100 %, lat/long in range and inside the facility country, YYYY-MM-DD dates, answers in the option list, checkboxes = X. |
| Legal flag | LEGAL-01..05 | X needs a Legal Reference. A violation needs X plus a reference (questions worded "Is the facility failing to …" count *Yes* as the violation). X on a compliant or "no applicable legal requirement" answer is flagged. |
| Specific | SPEC-.. | 60 h and rest days, forced vs voluntary overtime, duplicate certifications and subcontractors, youngest worker, volume vs capacity, contact details, harassment cases, working-hour thresholds, sampling vs answers, OS ID format. |
| Relevance | REL-01..06 | Child answered while the parent's answer doesn't trigger it. "None of the above" ticked with other options. Breakdown > total. Implausible proportions. Visible questions left unanswered. |
| Plausibility | PLAUS-01..04 | Nationalities, languages or wage grades = 0; lead time over 52 weeks; a wage of 0 for one gender only; built area under 2 m² per worker. |

Thresholds are constants at the top of `slcp_qc_checker.py`.

## Calibration on real reports
The relationship, plausibility and selection rules were run against 1,000 randomly sampled, anonymised platform VRFs. A rule that fires on a large share of genuine, verified reports is more likely wrong than the reports, so those rules were adjusted. For example: OSH committee members are flagged only when employer + worker members *exceed* the total; take-home pay only below 80 % of the basic wage; a Legal Reference without X is Info only; unticked checklist options marked Accurate or Not visible are not flagged. Only aggregated rates were used, and no report data is included in this package.

This is a self-check aid for verifiers. It does not replace the SLCP verification protocol or a verifier body's quality review.
