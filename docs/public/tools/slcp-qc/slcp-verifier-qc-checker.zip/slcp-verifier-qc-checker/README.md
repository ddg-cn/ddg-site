# SLCP Verifier Tool – Quality Checker

Checks a filled offline **SLCP Verifier Tool (1.7.x)** and writes an Excel report. The tool file itself is never modified.

There are two ways to use it:
- **Online:** https://scdd.pro/en/slcp-qc.html (中文: https://scdd.pro/zh/tools/slcp-qc.html) runs this checker inside your browser. The file is not uploaded anywhere.
- **On your PC:** use this package (below).

## How to run
Requires Python 3.9+ with `openpyxl` (`py -m pip install openpyxl`).
- **Drag and drop:** drop one or more `.xlsm` files onto `Run Quality Checker.bat`.
- **Command line:** `py slcp_qc_checker.py "<tool>.xlsm" [-o "<report>.xlsx"]`

The report is saved next to the tool as `<tool name> - QC Report <yymmdd>.xlsx`. It has three sheets:
- **Summary:** counts per rule, plus checks that could not run on this tool.
- **Issues:** one row per finding with severity, rule, question number and key. The *Tool Row* link opens the tool at that row (keep the report in the same folder as the tool).
- **Rules:** the full rule catalogue.

Severity: **Error** = must fix · **Warning** = review · **Info** = note.

## What it reads
- Inputs come from the `SLCP Data Collection Tool` sheet: S Facility Response, Y Verification Selection, AB Corrected Response, AH Verification Data, AN Non-Compliance, AP Legal Reference.
- Question metadata (data type, option list, show/hide logic, verification type, multi-select groups) comes from `Main Survey Actual`, so question numbers in the report are the ones your tool shows.
- The **effective answer** is the Corrected Response if one is given, otherwise the Facility Response. An *Inaccurate* checklist option with a blank correction counts as un-ticked. All logic and relevance checks use the effective answer, and questions that are hidden by show/hide logic are not checked.

## Rule groups
| Group | IDs | Summary |
|---|---|---|
| Language | LANG-01..04 | Verification Data, Corrected Response and verifier answers in English (except "in local language as per business license" questions). A facility answer in another language cannot be *Accurate*. |
| Selection | SEL-01..18 | Accurate → no correction. Any correction must differ from the facility answer. Inaccurate/Updated → a correction plus Verification Data. A blank facility answer only with *Facility did not reply*, *Not visible*, *No longer applicable* or *Verification only*. No longer applicable → no correction or data. A facility answer needs a selection, and the selection must be in the question's list. Verification Data is required for mandatory narrative keys, *Not applicable due to special facility circumstances* and *Facility did not reply*, is at most 6,000 characters and must contain "Reason:" plus a source. Unticked checklist options are valid answers. |
| Data type | DATA-01..09 | Whole numbers, non-negative numbers, 0–100 %, lat/long in range and inside the facility country, YYYY-MM-DD dates (required dates not blank), answers in the option list, checkboxes = X. |
| Legal flag | LEGAL-01..07 | X needs a Legal Reference and a Legal Reference needs X. X with a reference needs Verification Data. A violation needs X plus a reference (questions worded "Is the facility failing to …" count *Yes* as the violation). X on a compliant or "no applicable legal requirement" answer is flagged. China with a union in place: legal non-compliance on the free-to-form, free-to-join and federations questions. |
| Specific | SPEC-.. | Validation method not *SLCP Full Virtual Verification*, 60 h and rest days, forced vs voluntary overtime, duplicate certifications and subcontractors, youngest worker, volume vs capacity, contact details, harassment cases, working-hour thresholds, sampling vs answers, OS ID format. |
| Relevance | REL-01..06 | Child answered while the parent's answer doesn't trigger it. "None of the above" ticked with other options. Breakdown > total. Implausible proportions. Visible questions left unanswered. |
| Plausibility | PLAUS-01..04 | Nationalities, languages or wage grades = 0; lead time over 52 weeks; a wage of 0 for one gender only; built area under 2 m² per worker. |
| Platform advisory | ADV-01..04 | The SLCP platform's advisory checks: non-consecutive verification days without a reason, no *Inaccurate - Incorrect* in the report, *Not applicable due to special facility circumstances* used, zero legal non-compliances. |

Thresholds are constants at the top of `slcp_qc_checker.py`.

## SLCP platform checks
Since November 2026 the SLCP platform runs automated data quality checks when a report is submitted ([list of checks, 2026-10-30](https://slcp.zendesk.com/hc/article_attachments/31495285677596)). Blocking checks stop submission; advisory checks only warn. The checker replicates them so you can fix them before upload. Rule titles show the matching platform check, for example *[SLCP #19]*.
- **Blocking (#1–#19), all Errors:** a selection for every facility answer (SEL-08); Accurate without a correction (SEL-01); youngest worker vs workers under 18 (SPEC-15); a blank facility answer only with *Facility did not reply*, *Not visible*, *No longer applicable* or *Verification only* (SEL-12); X and Legal Reference always together (LEGAL-01, LEGAL-04); Verification Data up to 6,000 characters (SEL-17); a correction that differs from the facility answer (SEL-02); explanations for *Updated*, *Inaccurate*, *Not applicable due to special facility circumstances* and *Facility did not reply* (SEL-04, SEL-14); verification end date not before the start date (SPEC-04); required dates filled in as YYYY-MM-DD (DATA-05, DATA-09); numeric formats (DATA-01..04); no *SLCP Full Virtual Verification* (SPEC-21); an explanation for every legal non-compliance (LEGAL-06); mandatory narrative keys (SEL-14); legal violations flagged (LEGAL-02); China with a union in place: legal non-compliance on the free-to-form, free-to-join and federations questions (LEGAL-07); every explanation contains **"Reason:"** and cites **Facility Walkthrough**, **Worker Interview**, **Management Interview** or **Documentation Review** (SEL-18).
- **Advisory (#29–#32), Warnings:** non-consecutive verification days without a reason (ADV-01); no *Inaccurate - Incorrect* in the whole report (ADV-02); *Not applicable due to special facility circumstances* used (ADV-03); zero legal non-compliances (ADV-04).
- **Not replicated:** #10 joint-assessment details (the offline tool has no such question) and #33 Better Work Zero Tolerance Protocol (the platform's answer list is not published). Both are listed under *Notes* in the report.

## Calibration on real reports
The relationship, plausibility and selection rules were run against 1,000 randomly sampled, anonymised platform VRFs. A rule that fires on a large share of genuine, verified reports is more likely wrong than the reports, so those rules were adjusted. For example: OSH committee members are flagged only when employer + worker members *exceed* the total; take-home pay only below 80 % of the basic wage; unticked checklist options marked Accurate or Not visible are not flagged. Only aggregated rates were used, and no report data is included in this package.

This is a self-check aid for verifiers. It does not replace the SLCP verification protocol or a verifier body's quality review.
