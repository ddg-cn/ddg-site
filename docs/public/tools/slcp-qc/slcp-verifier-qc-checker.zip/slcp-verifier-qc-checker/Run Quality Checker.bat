@echo off
REM Drag a filled SLCP Verifier Tool (.xlsm) onto this file to check it.
if "%~1"=="" (
  echo Drag a filled Verifier Tool .xlsm file onto this .bat file.
  pause
  exit /b
)
for %%F in (%*) do py "%~dp0slcp_qc_checker.py" %%F
pause
