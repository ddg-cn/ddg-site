"""Injection tests: each case modifies inputs in memory and expects (rule, key) to appear (or not)."""
import sys
import vt_quality_checker as q

BASE = sys.argv[1] if len(sys.argv) > 1 else "vt_filled.xlsm"
chk = q.Checker(BASE)
FIELDS = ("fac", "sel", "cor", "exp", "nc", "lr")
snap = {it.key: tuple(getattr(it, f) for f in FIELDS) for it in chk.items}


def run(changes):
    for it in chk.items:
        for f, v in zip(FIELDS, snap[it.key]):
            setattr(it, f, v)
    for key, kv in changes.items():
        it = chk.by_key[key]
        for f, v in kv.items():
            setattr(it, f, v)
    chk.issues, chk.skipped, chk._eff_cache, chk._rel_cache = [], [], {}, {}
    chk.run()
    return {(x.rule, x.item.key) for x in chk.issues}


baseline = run({})
A, INC, UPD = "Accurate", "Inaccurate - Incorrect", "Updated during Verification"
NV, NLA = "Not visible to facility during SA/JA", "No longer applicable due to assessment/verification"

cases = [
    # (description, changes, expected (rule,key), should_fire)
    ("Chinese verification data", {"fp-bi-9": {"exp": "工人每天工作八小时"}}, ("LANG-01", "fp-bi-9"), True),
    ("Indonesian verification data", {"fp-bi-9": {"exp": "Pekerja tidak dibayar dengan benar dan ada yang belum menerima upah dari perusahaan"}}, ("LANG-01", "fp-bi-9"), True),
    ("Local-language question exempt", {"fp-bi-3": {"fac": "广州市服装有限公司", "exp": "营业执照"}}, ("LANG-01", "fp-bi-3"), False),
    ("Local-language facility answer Accurate ok", {"fp-bi-3": {"fac": "广州市服装有限公司"}}, ("LANG-03", "fp-bi-3"), False),
    ("Thai corrected response", {"fp-bi-10": {"sel": INC, "cor": "สองกะ", "exp": "Checked shift records"}}, ("LANG-02", "fp-bi-10"), True),
    ("Non-English facility answer marked Accurate", {"fp-bi-10": {"fac": "Hai ca làm việc, sáng và chiều", "sel": A}}, ("LANG-03", "fp-bi-10"), True),
    ("Verifier detail in Chinese", {"vd-e15": {"fac": "访谈了二十名工人"}}, ("LANG-04", "vd-e15"), True),
    ("Accurate with correction", {"fp-bi-10": {"sel": A, "cor": "2 shifts"}}, ("SEL-01", "fp-bi-10"), True),
    ("Inaccurate same answer", {"fp-bs-13": {"fac": "Yes", "sel": INC, "cor": "Yes", "exp": "Checked"}}, ("SEL-02", "fp-bs-13"), True),
    ("Inaccurate no correction", {"fp-bs-13": {"fac": "Yes", "sel": INC, "cor": None, "exp": "Checked the building"}}, ("SEL-03", "fp-bs-13"), True),
    ("Inaccurate checkbox unticked ok", {"fp-pi-1-1": {"fac": "X", "sel": INC, "cor": None, "exp": "Not in this sector"}}, ("SEL-03", "fp-pi-1-1"), False),
    ("Inaccurate no explanation", {"fp-bs-13": {"fac": "Yes", "sel": INC, "cor": "No", "exp": None}}, ("SEL-04", "fp-bs-13"), True),
    ("Updated no explanation", {"fp-ed-2": {"sel": UPD, "cor": "120", "exp": None}}, ("SEL-04", "fp-ed-2"), True),
    ("Not visible but facility answered", {"fp-bs-13": {"fac": "Yes", "sel": NV, "cor": "No"}}, ("SEL-05", "fp-bs-13"), True),
    ("Not visible no correction", {"os-work-1": {"cor": None}}, ("SEL-06", "os-work-1"), True),
    ("NLA with correction", {"fp-man-4": {"cor": "No"}}, ("SEL-07", "fp-man-4"), True),
    ("NLA with explanation", {"fp-man-4": {"exp": "because"}}, ("SEL-07", "fp-man-4"), True),
    ("Facility answered no selection", {"fp-bs-13": {"sel": None}}, ("SEL-08", "fp-bs-13"), True),
    ("Follow-up selection n/a", {"fp-pi-1-10": {"sel": "N/A"}}, ("SEL-09", "fp-pi-1-10"), True),
    ("Updated on base-verf invalid", {"fp-man-1": {"sel": UPD}}, ("SEL-10", "fp-man-1"), True),
    ("Fraction of a person", {"fp-ed-2": {"fac": 100.5, "sel": A}}, ("DATA-01", "fp-ed-2"), True),
    ("Negative workers", {"fp-ed-3": {"fac": -3}}, ("DATA-01", "fp-ed-3"), True),
    ("Text in number", {"fp-ed-6": {"fac": "about 7"}}, ("DATA-01", "fp-ed-6"), True),
    ("Cases numeric with decimals", {"hb-4": {"fac": "Yes"}, "wt-har-3": {"fac": 1.5}}, ("DATA-01", "wt-har-3"), True),
    ("Percentage over 100", {"fp-wor-2": {"fac": 120}}, ("DATA-03", "fp-wor-2"), True),
    ("Latitude out of range", {"fp-bas-5": {"fac": 123.4}}, ("DATA-04", "fp-bas-5"), True),
    ("Geo outside country", {"fp-bas-5": {"fac": 40.7}, "fp-bas-6": {"fac": -74.0}}, ("DATA-04", "fp-bas-5"), True),
    ("Geo swapped", {"fp-bas-5": {"fac": 106.8}, "fp-bas-6": {"fac": -6.2}}, ("DATA-04", "fp-bas-5"), True),
    ("Geo valid Jakarta", {"fp-bas-5": {"fac": -6.2}, "fp-bas-6": {"fac": 106.8}}, ("DATA-04", "fp-bas-5"), False),
    ("Bad date", {"fp-bui-12": {"fac": "30/09/2020"}}, ("DATA-05", "fp-bui-12"), True),
    ("Invalid option", {"fp-bs-13": {"fac": "Maybe"}}, ("DATA-06", "fp-bs-13"), True),
    ("Checkbox with Yes", {"fp-pi-1-1": {"fac": "Yes"}}, ("DATA-07", "fp-pi-1-1"), True),
    ("X without legal reference", {"wh-5--1": {"lr": "N/A"}}, ("LEGAL-01", "wh-5--1"), True),
    ("Violation without flag", {"wh-5--1": {"nc": None, "lr": None}}, ("LEGAL-02", "wh-5--1"), True),
    ("Comply No without flag", {"os-eme-11": {"fac": "No"}}, ("LEGAL-02", "os-eme-11"), True),
    ("Minimum age Yes needs flag", {"rh-chi-13": {"fac": "Yes"}}, ("LEGAL-02", "rh-chi-13"), True),
    ("cl-2 remediation Yes is not a violation", {}, ("LEGAL-02", "cl-2"), False),
    ("wb-19 'other than legally required' is not a violation", {}, ("LEGAL-02", "wb-19"), False),
    ("Paid the legal minimum is not a violation", {}, ("LEGAL-02", "wh-ove-10"), False),
    ("NALR with X", {"wh-5--1": {"fac": "No Applicable Legal Requirements"}}, ("LEGAL-03", "wh-5--1"), True),
    ("Legal ref without X", {"wh-6": {"lr": "Labour Law Art. 77"}}, ("LEGAL-04", "wh-6"), True),
    ("60h + 2 rest days", {"wh-5": {"fac": 62}, "wh-wor-20": {"fac": 2}}, ("SPEC-01", "wh-wor-20"), True),
    ("3 rest days not legal", {"wh-wor-20": {"fac": 3}, "wh-9--1": {"fac": "No"}}, ("SPEC-02", "wh-9--1"), True),
    ("Forced + voluntary OT", {"fl-7--1": {"fac": "Yes"}, "wh-ove-2": {"fac": "Yes"}}, ("SPEC-03", "wh-ove-2"), True),
    ("Start after end", {"vd-e4": {"fac": "2023-04-20"}}, ("SPEC-04", "vd-e4"), True),
    ("Certification in Other duplicates list", {"fp-cer-45f": {"fac": "SMETA 4-pillar audit"}}, ("SPEC-05", "fp-cer-45f"), True),
    ("Duplicate subcontractor", {"fp-sub-1": {"fac": "Yes"}, "fp-sub-2": {"fac": 2}, "fp-sub-4": {"fac": "ABC Printing Co."},
                                 "fp-sub-5": {"fac": "ABC Printing Co"}}, ("SPEC-06", "fp-sub-5"), True),
    ("Youngest 13 but no under-age", {"cl-1--2": {"fac": 13}, "rh-chi-13": {"fac": "No"}}, ("SPEC-07", "rh-chi-13"), True),
    ("Volume > capacity", {"fp-pi-10": {"fac": 5000}, "fp-pi-13": {"fac": 4000}, "fp-pi-11": {"fac": "Meter"}, "fp-pi-14": {"fac": "Meter"}},
     ("SPEC-08", "fp-pi-10"), True),
    ("Contact name digits", {"fp-bi-13": {"fac": "123456"}}, ("SPEC-09", "fp-bi-13"), True),
    ("Phone no digits", {"fp-bi-15": {"fac": "ask reception"}}, ("SPEC-10", "fp-bi-15"), True),
    ("Prison No, none ticked", {"fl-pri-1": {"fac": "No"}, "rh-for-3": {"fac": None}, "rh-for-4": {"fac": None}, "rh-for-5": {"fac": None}},
     ("SPEC-11", "fl-pri-1"), True),
    ("Harassment cases 0/0", {"hb-4": {"fac": "Yes"}, "wt-har-3": {"fac": 0}, "wt-har-4": {"fac": 0}}, ("SPEC-12", "wt-har-3"), True),
    ("Bad email", {"fp-bi-17": {"fac": "info(at)abc.com"}}, ("SPEC-13", "fp-bi-17"), True),
    ("Weekly hours > 72 but 72 No", {"wh-5": {"fac": 75}, "wh-7": {"fac": "Yes"}, "wh-7--1": {"fac": "No"}}, ("SPEC-14", "wh-7--1"), True),
    ("VD weeks >60 vs WH No", {"vd-veri-35": {"fac": 4}, "vd-veri-36": {"fac": 2}, "wh-7": {"fac": "No"}}, ("SPEC-18", "wh-7"), True),
    ("Duplicate nationality", {"fp-nat-1": {"fac": 2}, "fp-nl-1": {"fac": "Indonesia"}, "fp-nl-2": {"fac": "Indonesia"}}, ("SPEC-17", "fp-nl-2"), True),
    ("Child answered, parent corrected to No", {"fp-bs-13": {"fac": "Yes", "sel": INC, "cor": "No", "exp": "Single floor"},
                                                "fp-bs-15": {"fac": "Yes", "sel": A}}, ("REL-01", "fp-bs-15"), True),
    ("Child NLA, parent corrected to No ok", {"fp-bs-13": {"fac": "Yes", "sel": INC, "cor": "No", "exp": "Single floor"},
                                              "fp-bs-15": {"fac": "Yes", "sel": NLA}}, ("REL-01", "fp-bs-15"), False),
    ("NLA but parent still Yes", {"fp-bs-13": {"fac": "Yes", "sel": A, "cor": None}, "fp-bs-15": {"fac": "Yes", "sel": NLA}}, ("REL-02", "fp-bs-15"), True),
    ("None of the above + other", {"fp-cer-47": {"fac": "X"}}, ("REL-03", "fp-cer-47"), True),
    ("Male > total", {"fp-ed-3": {"fac": 102, "sel": A, "cor": None}}, ("REL-04", "fp-ed-3"), True),
    ("Female union > total union", {"foa-cb-2": {"fac": "Yes"}, "foa-cb-2--2": {"fac": 1}, "wi-foa-61": {"fac": 40}, "wi-foa-6": {"fac": 45}}, ("REL-04", "wi-foa-6"), True),
    ("Supervisors > 50%", {"fp-ed-19": {"fac": 60}}, ("REL-05", "fp-ed-19"), True),
    ("Sync mismatch", {"fp-bi-1": {"fac": "Company XYZ"}}, ("SYNC-01", "fp-bi-1"), True),
    # v1.1 - thresholds calibrated on real VRFs
    ("OSH employer + worker > total", {"os-osh-1": {"fac": "Yes", "sel": A, "cor": None}, "hs-hsc-2": {"fac": 6}, "hs-hsc-5": {"fac": 4}, "hs-hsc-6": {"fac": 4}}, ("REL-04", "hs-hsc-6"), True),
    ("OSH employer + worker < total ok", {"os-osh-1": {"fac": "Yes", "sel": A, "cor": None}, "hs-hsc-2": {"fac": 10}, "hs-hsc-5": {"fac": 4}, "hs-hsc-6": {"fac": 4}}, ("REL-04", "hs-hsc-6"), False),
    ("OSH employer + worker < total not REL-05", {"os-osh-1": {"fac": "Yes", "sel": A, "cor": None}, "hs-hsc-2": {"fac": 10}, "hs-hsc-5": {"fac": 4}, "hs-hsc-6": {"fac": 4}}, ("REL-05", "hs-hsc-6"), False),
    ("Take-home 90 % of basic ok", {"wb-wage-41": {"fac": 1000}, "wb-wage-47": {"fac": 900}}, ("REL-05", "wb-wage-47"), False),
    ("Take-home 70 % of basic", {"wb-wage-41": {"fac": 1000}, "wb-wage-47": {"fac": 700}}, ("REL-05", "wb-wage-47"), True),
    ("Zero nationalities", {"fp-nat-1": {"fac": 0}}, ("PLAUS-01", "fp-nat-1"), True),
    ("Zero languages", {"fp-lan-1": {"fac": 0}}, ("PLAUS-01", "fp-lan-1"), True),
    ("Lead time 90 weeks", {"fp-pi-20": {"fac": 90}}, ("PLAUS-02", "fp-pi-20"), True),
    ("Lead time 12 weeks ok", {"fp-pi-20": {"fac": 12}}, ("PLAUS-02", "fp-pi-20"), False),
    ("Female basic wage 0", {"wb-wage-41": {"fac": 1000}, "wb-wage-42": {"fac": 0}}, ("PLAUS-03", "wb-wage-42"), True),
    ("Area 1 m2 per worker", {"fp-bs-10": {"fac": 100, "sel": A, "cor": None}, "fp-ed-2": {"fac": 100, "sel": A, "cor": None}}, ("PLAUS-04", "fp-bs-10"), True),
]

ok = 0
for desc, ch, exp, should in cases:
    got = run(ch)
    fired = exp in got
    new = fired and (exp not in baseline or not should)
    passed = (fired == should) if not should else (fired and (exp not in baseline or ch == {}))
    if should and exp in baseline:
        passed = fired  # was already firing on baseline; still counts if fires
    ok += passed
    print(("PASS " if passed else "FAIL ") + f"{desc:55s} expect {'' if should else 'NO '}{exp}")
    if not passed:
        print("     related:", sorted(x for x in got if x[1] == exp[1] or x[0] == exp[0])[:8])
print(f"\n{ok}/{len(cases)} passed")
