# SLCP Verifier Tool 2.0.0 – Quality Checker

Checks a filled offline Verifier Tool and writes an Excel report. The tool file itself is never modified.

## How to run
- **Drag and drop:** drop one or more `.xlsm` files onto `Run Quality Checker.bat`.
- **Command line:** `py vt_quality_checker.py "<tool>.xlsm" [-o "<report>.xlsx"]`

The report is saved next to the tool as `<tool name> - QC Report <yymmdd>.xlsx`. It has three sheets:
- **Summary:** counts per rule, plus checks that could not run on this template.
- **Issues:** one row per finding with severity, rule, question number and key. The *Tool Row* link opens the tool at that row (keep the report in the same folder as the tool).
- **Rules:** the full rule catalogue.

Severity: **Error** = must fix · **Warning** = review · **Info** = note.

## What it reads
- Inputs come from the `SLCP Data Collection Tool` sheet: S Facility Response, Y Verification Selection, AB Corrected Response, AH Verification Data, AN Non-Compliance, AP Legal Reference, AZ key, BA visible.
- Question metadata comes from `Main Survey Actual`: data type, option list, show/hide logic, verification type, multi-select groups and legal-flag list. The plain copy of the inputs in that sheet is checked for sync (SYNC-01).
- The **effective answer** is the Corrected Response if one is given, otherwise the Facility Response. A blank answer means "No longer applicable". An *Inaccurate* checkbox with a blank correction counts as un-ticked. All logic and relevance checks use the effective answer.

## Rule groups
| Group | IDs | Summary |
|---|---|---|
| Language | LANG-01..04 | Verification Data, Corrected Response and verifier answers must be English (except questions marked "in local language as per business license"). A facility answer in another language cannot be *Accurate*. Non-Latin script = Error; Vietnamese/Turkish characters or foreign common words = Warning. |
| Selection | SEL-01..16 | Accurate → no correction. Inaccurate/Updated → correction differs from the facility answer and has Verification Data. Not visible → facility answer blank, correction expected. No longer applicable → no correction or data. A facility answer needs a selection. Follow-ups can't be blank or N/A. The selection must be in the question's list. Also: mandatory narrative, placeholder text, verification-only rows. |
| Data type | DATA-01..08 | Whole numbers (no 0.1 people), non-negative numbers, 0–100 %, lat/long in range and inside the facility country (or swapped), valid YYYY-MM-DD dates, answers in the option list, checkboxes = X. |
| Legal flag | LEGAL-01..05 | X needs a Legal Reference (not blank or N/A). A legal-requirement question answered as a violation needs X plus a reference. X on a compliant or NALR answer is flagged. A Legal Reference without X is Info only (common in real reports). |
| Specific | SPEC-01..20 | 60 h + 2 rest days, rest days > 2 but "not legal", forced vs voluntary OT, start/end dates, certification and subcontractor duplicates, youngest worker < 14, volume > capacity, contact name/phone/email, prison labour, harassment cases male/female both 0, working-hours thresholds, sampling vs answers, OS ID format. |
| Relevance | REL-01..06 | Child answered while the parent's effective answer doesn't trigger it (e.g. parent corrected to No). NLA while the parent still triggers it. "None of the above" ticked with other options. Breakdown > total (male > total, female union members > members…). Implausible proportions (supervisors > 50 %, take-home pay < 80 % of basic). OSH committee employer + worker members > total. Visible questions left unanswered. |
| Plausibility | PLAUS-01..04 | Nationalities, languages or wage grades = 0; lead time > 52 weeks; a wage of 0 for one gender only; built area < 2 m² per worker. |

Thresholds are constants at the top of `vt_quality_checker.py`.

## Calibration on real reports (v1.1)
The relationship and plausibility rules were run against 1,000 randomly sampled, anonymised platform VRFs (tool versions 1.4-1.7.1). A rule that fires on a large share of genuine, verified reports is more likely wrong than the reports, so:
- **OSH committee:** employer + worker members ≠ total fired on 37 % of reports (committees often have other members). Now only *more than* the total is flagged (3 %).
- **Take-home pay < basic wage** fired on 18 % (deductions). Now flagged below 80 % of basic (6 %).
- **Largest union members > total workers** fired on 13 %; now a Warning.
- **Legal Reference without X** appears in 60 % of legal references; now Info.
- New **PLAUS** rules each fire on 0.1-3.4 % of reports.
- Most breakdown > total violations in the data came from hidden questions holding stale values. The checker already ignores questions that are not relevant, so they are not reported.

Only aggregated rates were used; no facility, verifier or report data is included in this package.

## Change log
- **1.1 (2026-10-23):** data-calibrated thresholds (above), new PLAUS-01..04, 11 new tests (76 in total).
- **1.0 (2026-10-05):** first release.

## Maintenance
- Question keys are hardcoded for v2.0.0 in the SPEC and REL-04/05 rules. If a key disappears in a later version, that rule is skipped and listed under *Notes* on the Summary sheet; it does not crash.
- `tests/test_qc.py` injects one error per rule into a filled tool and checks the rule fires. Run it from the `tests` folder: `py test_qc.py "<filled tool>.xlsm"`, with `vt_quality_checker.py` copied next to it or on PYTHONPATH.
- Requires Python 3.9+ with `openpyxl`.
